# Siftcord Android starter

## Build a test APK using GitHub Actions
1. Download and extract this ZIP.
2. Create a new GitHub repository.
3. Upload the **contents** of this folder into the repository root.
4. Open **Actions** → **Build Siftcord APK** → **Run workflow** (or push to `main`/`master`).
5. When it finishes, open the workflow run and download the `Siftcord-APK` artifact.
6. Extract that artifact ZIP and install `app-debug.apk` on your Android phone.

## Demo owner login
Email: `admin@gmail.com`
Password: `admin_123`

**Security:** this is a UI prototype and the demo credentials are in the app's client-side code. Do not publish this build or reuse that password for any real account. Change the password and implement server-side authentication before public use.

## Important limits
This builds a test Android APK for a Siftcord interface prototype, not a complete Discord replacement. Real accounts, synced servers, multi-user real-time chat, voice/video calls, file uploads, moderation, bot hosting/developer portal, Nitro payments and secure owner permissions require a backend, database, realtime services and additional development. This app cannot manage official Discord servers or grant official Discord Nitro.
