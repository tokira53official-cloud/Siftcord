# SiftCord Android Starter

A mobile-first SiftCord UI prototype inspired by the navigation patterns of modern chat/community apps. App name and the supplied SiftCord logo URL are set in the interface.

## Build an APK
This project is a standard Android Gradle project. GitHub Actions runs `.github/workflows/build-apk.yml` on pushes to `main`/`master` and uploads `Siftcord-APK` as an artifact. The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
The current UI demo supports local navigation, sample servers/channels, sample direct messages, and sending messages in the current app session. It does **not** include a backend, secure accounts, cross-device message sync, real multi-user messaging, real voice/video calls, push notifications, or premium payments. Those require a server and authentication/database integrations. Demo messages are not shared with other users.
